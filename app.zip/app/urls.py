from django.contrib import admin
from django.urls import path
from app import views


urlpatterns = [
    path('',views.welcome,name='welcome'),
    path('demo/',views.demo,name='demo'),
    path('demo1/',views.demo1,name='demo1'),
    path('demo2/',views.demo2,name='demo2'),
    path('demo3/',views.demo3,name='demo3'),
    path('demo4/',views.demo4,name='demo4'),
    path('demo5/',views.demo5,name='demo5'),
    path('demo6/',views.demo6,name='demo6'),
    path('demo7/',views.demo7,name='demo7'),
    path('demo8/',views.demo8,name='demo8'),
    path('demo9/',views.demo9,name='demo9'),
    path('demo10/',views.demo10,name='demo10'),
    path('demo11/',views.demo11,name='demo11'),
    path('fav/',views.fav,name='fav'),
     path('e/',views.e,name='e'),


    path('Singup/',views.Signup,name='Signup'),
    path('Login/',views.Login,name='Login'),
    path('Home/',views.Home,name='Home'),
    path('Logout/',views.Logout,name='Logout'),
    
]


