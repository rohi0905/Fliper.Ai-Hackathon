from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
# Create your views here.
@login_required(login_url='Login')
def Home(request):
    return render (request,'home.html')

def demo(request):
    return render (request,'demo.html')
def demo1(request):
    return render (request,'demo1.html')
def demo2(request):
    return render (request,'demo2.html')
def demo3(request):
    return render (request,'demo3.html')
def demo4(request):
    return render (request,'demo4.html')
def demo5(request):
    return render (request,'demo5.html')
def demo6(request):
    return render (request,'demo6.html')
def demo7(request):
    return render (request,'demo7.html')
def demo8(request):
    return render (request,'demo8.html')
def demo9(request):
    return render (request,'demo9.html')
def demo10(request):
    return render (request,'demo10.html')
def demo11(request):
    return render (request,'demo11.html')
def fav(request):
    return render (request,'fav.html')
def e(request):
    return render (request,'episode.html')

def welcome(request):
    return render (request,'welcome.html')

def Signup(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('Home')
        
    return render (request,'signup.html')

def Login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('Home')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render (request,'Login.html')

def Logout(request):
    logout(request)
    return redirect('Logout')

